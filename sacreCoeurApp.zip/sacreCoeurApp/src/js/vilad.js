//verifiie le formulaire d'enregistrement d'un nouveau user	
function verifForm() 
{ var message = ""; var message1="Veuillez entrer ";

	
	if ( document.inscRG_form.email.value == "" ) { message += "- Veuillez entrer votre adresse email !\n";} 
	
	if ( document.inscRG_form.psw.value == "" ) { message += "- Veuillez entrer un mot de passe valide !\n";} 
	if ( document.inscRG_form.rpsw.value == "" ) { message += "- Veuillez entrer la confirmation de votre mot de passe !\n";} 
		
	if (document.inscRG_form.psw.value!=document.inscRG_form.rpsw.value) {message+="-Le champ 'Mot de passe' et le champ 'Confirmez le mot de passe' doivent \u00eatre identiques\n";}
		
	if (message!="") {
		alert (message);
	}
	else {
		document.Formulaire_nvprod.submit();
	}
}


