<!-- 22/12/2018 -->
<!-- // first making the fornt page -->

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/> 
		<title>
			Ecole de Sacr&eacute; Coeur
		</title>
		<link rel="stylesheet" type="text/css" href="assets/css/main.css" />
	</head>
	<body>
		<div class="container">
		<h1> csndosjnonvsdv qcnx </h1>
			<div class="circle-container">
				<ul class="circle-item">
					<li><img alt="logo" src="assets/img/1.png"/></li>
					<li><img alt="logo" src="assets/img/2.png"/></li>
					<li><img alt="logo" src="assets/img/3.png"/></li>
					<li><img alt="logo" src="assets/img/4.png"/></li>
					<li><img alt="logo" src="assets/img/5.png"/></li>
					<li><img alt="logo" src="assets/img/6.png"/></li>
					<li><img alt="logo" src="assets/img/7.png"/></li>
					<li><img alt="logo" src="assets/img/ecoleLogo.JPG"/></li>
				</ul>
			</div>
			<hr>
			<div>
				dhflsjkdhudsofn
			</div>
		</div>
	</body>
</html>