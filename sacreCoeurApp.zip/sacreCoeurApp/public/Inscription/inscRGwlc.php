<!-- 22/12/2018 -->
<!-- // first making the inscription login page -->

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/> 
		<title>
			Ecole de Sacr&eacute; Coeur ORGERES INSCRG wlc page
		</title>
		
		<link rel="stylesheet" type="text/css" href="../assets/css/inscLG.css" />
		<link rel="shortcut icon" href="../assets/img/ecoleLogo.jpg" type="image/jpg" />

	</head>
	<body>
		<div class="bdy">
			<div class="mu">
				<ul>
					<li ><a href="../index.php"> ACCUEIL </a></li>
					<li ><a href="#"> INSCRIPTIONS</a></li>
				</ul>
			</div>
			<div class="inbd">
				<div class="Mwp">
					<center>
						<h2><b><em>Inscpritions</em></b> </h2>
						<img class="g" alt="pic" src="../assets/img/cl1.PNG" name="slide" >
					</center>
					
					    <h2><b><em> Merci de vous &ecirc;tre inscrit, confirmez votre inscription dans votre email <br> afin de continuer l'inscription de votre enfant ou de vos enfants. </em></b> </h2>
				</div>
			</div>
		</div>
		<script  type="text/javascript" src="../../src/js/inscp.js"></script>
	</body>
</html>
