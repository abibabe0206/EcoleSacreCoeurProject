<?php echo "good"; 
?>