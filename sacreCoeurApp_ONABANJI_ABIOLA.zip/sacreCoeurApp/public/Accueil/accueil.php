<!-- 22/12/2018 -->
<!-- // first making the contact us -->
<!-- //AUTHOR BY ONABANJI ABIOLA -->

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/> 
		<title>
			Ecole de Sacr&eacute; Coeur ORGERES contact us page
		</title>
		
		<link rel="stylesheet" type="text/css" href="../assets/css/accueil.css" />
		<link rel="shortcut icon" href="../assets/img/ecoleLogo.jpg" type="image/jpg" />

	</head>
	<body>
		<div class="bdy">
			<div class="mu">
				<ul>
					<li ><a href="../index.php"> ACCUEIL </a></li>
					<li ><a href="#"> DIRECTEUR d'ECOLE</a></li>
					<li><a href="#"> HISTOIRS</a></li>
				</ul>
			</div>
			<div class="inbd">
				<p>
					<img class="g" alt="dir" src="../assets/img/dictSch.png"> <em><b>B</b>ienvenue &agrave; tous sur le blog de l'&eacute;cole du Sacr&eacute; C&oelig;ur d'Org&egrave;res.
						Que vous soyez futur parent, parent de l'&eacute;cole ou simple naviguant sur Internet, 
						ce site ne doit pas seulement &ecirc;tre un lieu de passage mais &eacute;galement un temps o&ugrave; vous 
						pouvez mieux conna&icirc;tre ce qui se vit au sein de notre &eacute;tablissement : vie scolaire, vie
						 associative et vie extra-scolaire.
							On sait que chaque enfant arrive dans l'&eacute;cole avec son v&eacute;cu personnel : v&eacute;cu plus ou moins 
							important suivant son &acirc;ge.
							Pour nous, enseignants, l'&eacute;cole n'est pas un lieu o&ugrave; les enfants perdent leurs rep&egrave;res.
							 Bien au contraire, c'est en relation avec les parents que nous devons aider les enfants qui
							  nous sont confi&eacute;s &agrave; trouver leurs marques dans la vie.

								L'&eacute;cole du Sacr&eacute;-C&oelig;ur est avant tout une &eacute;cole catholique o&ugrave; chacun &agrave; le droit de s'&eacute;panouir dans
								 le respect de l'autre une &eacute;cole proche de vous
								 <b>Dominique Heude, Chef d'&eacute;tablissement</b></em>
				</p>
			</div>
		</div>
		
	</body>
</html>
