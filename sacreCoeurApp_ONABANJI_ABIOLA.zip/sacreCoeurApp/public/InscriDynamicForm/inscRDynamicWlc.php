<!-- 22/12/2018 -->
<!-- // first making the inscription registertion welcome page after registering your children -->
<!-- //AUTHOR BY ONABANJI ABIOLA -->

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8"/> 
		<title>
			Ecole de Sacr&eacute; Coeur ORGERES INSCRG wlc page
		</title>
		
		<link rel="stylesheet" type="text/css" href="../assets/css/inscRGWlcPg.css" />
		<link rel="shortcut icon" href="../assets/img/ecoleLogo.jpg" type="image/jpg" />

	</head>
	<body>
		<div class="bdy">
			<div class="mu">
				<ul>
					<li ><a href="../index.php"> ACCUEIL </a></li>
					<li ><a href="../Inscription/inscLG.php"> CONNEXION</a></li>
				</ul>
				<a href="../Inscription/LogOut.php"><input type="button" id="reg_btn" value=" Déconnexion"></a>
			</div>
			<div class="inbd">
				<div class="Mwp">
					<center>
						<h2><b><em>Inscpritions des Enfants Terminée</em></b> </h2>
						<img class="g" alt="pic" src="../assets/img/cl1.PNG" name="slide" >
					</center>
					
					    <h2><b><em> Merci d'avoir inscrit vos enfants dans notre école. <br> Nous serons contents de vous voir ainsi que vos enfants à la date de reprise. 
					    <br> Vous pouvez vous conecter maintenant. Merci </em></b> </h2>
				</div>
			</div>
		</div>
		<script  type="text/javascript" src="../../src/js/inscp.js"></script>
	</body>
</html>
